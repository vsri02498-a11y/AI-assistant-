ZenChat — Notification Center phase
===================================

Included files
--------------
- zenchat_notifications_phase_next.html  Main application (HTML + CSS + JS)
- zenchat-sw.js                           Service worker for persistent notifications and notification clicks
- zenchat.webmanifest                     PWA manifest (standalone display)
- zenchat-icon-180.png                    Apple Home Screen icon
- zenchat-icon-192.png                    PWA icon
- zenchat-icon-512.png                    PWA / install icon

Run locally
-----------
1. Keep all files in the same folder.
2. Open a terminal in that folder.
3. Run: python -m http.server 8000
4. Open: http://localhost:8000/zenchat_notifications_phase_next.html
5. In ZenChat, open Settings > Notifications > Enable browser alerts.

Do not open the HTML with file:// when testing service-worker notifications. Browsers require
HTTPS or localhost for Service Worker and Notifications APIs. In-app notification history
still works without browser permission.

What works in this phase
------------------------
- In-app notification center with unread count and message previews.
- Open a notification to jump to its original conversation/message.
- Mark all notifications read and clear notification history.
- Persistent notification records stored as part of the existing ZenChat application state.
- In-app notification toast preference and browser-notification permission setting.
- Service worker registration and persistent notifications when the hosted browser supports it.
- Service-worker notification-click routing back to the conversation.
- Service-worker push-event handler scaffold for a future server push sender.
- Per-chat mute suppresses toast and OS alert, while the incoming message remains in the inbox.

Important limitation
--------------------
This project is still a browser-local messenger. The included service worker can display a
notification when it receives a push event, but this phase does not create a push subscription,
chat backend, or server-side push sender. Therefore it does NOT yet deliver messages from
another device while the app is closed. That requires the next backend/Web Push integration.

For iPhone/iPad Web Push, deploy over HTTPS, install the site as a Home Screen web app, and
use a server-side Web Push sender. Apple's WebKit documentation describes Home Screen Web
Push support on iOS/iPadOS 16.4 and later.
